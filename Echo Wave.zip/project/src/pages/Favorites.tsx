import { useLibrary } from '../contexts/LibraryContext';
import { SongCard } from '../components/SongCard';

export function Favorites() {
  const { favorites } = useLibrary();

  return (
    <div className="py-8">
      <h1 className="text-3xl font-bold mb-6">Your Favorites</h1>
      <div className="space-y-2">
        {favorites.length === 0 ? (
          <p className="text-gray-400">No favorite songs yet. Start adding some!</p>
        ) : (
          favorites.map(song => (
            <SongCard key={song.id} song={song} variant="compact" />
          ))
        )}
      </div>
    </div>
  );
}