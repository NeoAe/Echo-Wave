import { FeaturedSection } from '../components/FeaturedSection';
import { PlaylistSection } from '../components/PlaylistSection';
import { ArtistSection } from '../components/ArtistSection';
import { featuredSongs, playlists, artists } from '../data';

export function Home() {
  return (
    <div className="space-y-12">
      <section className="text-center mb-16">
        <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-pink-600 text-transparent bg-clip-text">
          Welcome to Echo Waves
        </h1>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto">
          Discover, stream, and share your favorite music. Your personal soundtrack starts here.
        </p>
      </section>

      <FeaturedSection songs={featuredSongs} />
      <PlaylistSection playlists={playlists} />
      <ArtistSection artists={artists} />
    </div>
  );
}