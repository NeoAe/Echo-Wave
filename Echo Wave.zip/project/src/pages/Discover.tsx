import { useState } from 'react';
import { GenreFilter } from '../components/discover/GenreFilter';
import { SongGrid } from '../components/discover/SongGrid';
import { featuredSongs } from '../data';

export function Discover() {
  const [selectedGenre, setSelectedGenre] = useState<string>('all');
  
  const genres = ['all', ...new Set(featuredSongs.map(song => song.genre))];
  const filteredSongs = selectedGenre === 'all' 
    ? featuredSongs 
    : featuredSongs.filter(song => song.genre === selectedGenre);

  return (
    <div className="py-8">
      <h1 className="text-3xl font-bold mb-6">Discover New Music</h1>
      <GenreFilter 
        genres={genres} 
        selectedGenre={selectedGenre} 
        onSelectGenre={setSelectedGenre} 
      />
      <SongGrid songs={filteredSongs} />
    </div>
  );
}