import { useLibrary } from '../contexts/LibraryContext';
import { SongCard } from '../components/SongCard';

export function Library() {
  const { library } = useLibrary();

  return (
    <div className="py-8">
      <h1 className="text-3xl font-bold mb-6">Your Library</h1>
      <div className="space-y-2">
        {library.length === 0 ? (
          <p className="text-gray-400">Your library is empty. Add songs to get started!</p>
        ) : (
          library.map(song => (
            <SongCard key={song.id} song={song} variant="compact" />
          ))
        )}
      </div>
    </div>
  );
}