import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './contexts/AuthContext';
import { PlayerProvider } from './contexts/PlayerContext';
import { LibraryProvider } from './contexts/LibraryContext';
import { PlaylistProvider } from './contexts/PlaylistContext';
import App from './App';
import './index.css';

const root = createRoot(document.getElementById('root')!);

root.render(
  <StrictMode>
    <AuthProvider>
      <PlayerProvider>
        <LibraryProvider>
          <PlaylistProvider>
            <App />
            <Toaster position="top-center" />
          </PlaylistProvider>
        </LibraryProvider>
      </PlayerProvider>
    </AuthProvider>
  </StrictMode>
);