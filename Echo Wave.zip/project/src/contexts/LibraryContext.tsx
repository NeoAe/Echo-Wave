import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Song } from '../types';
import { useAuth } from './AuthContext';
import toast from 'react-hot-toast';

interface LibraryContextType {
  favorites: Song[];
  library: Song[];
  addToFavorites: (song: Song) => void;
  removeFromFavorites: (songId: string) => void;
  addToLibrary: (song: Song) => void;
  removeFromLibrary: (songId: string) => void;
  isFavorite: (songId: string) => boolean;
  isInLibrary: (songId: string) => boolean;
}

const LibraryContext = createContext<LibraryContextType | null>(null);

export function LibraryProvider({ children }: { children: ReactNode }) {
  const [favorites, setFavorites] = useState<Song[]>([]);
  const [library, setLibrary] = useState<Song[]>([]);
  const { user } = useAuth();

  // Load saved data from localStorage when user changes
  useEffect(() => {
    if (user) {
      const savedFavorites = localStorage.getItem(`favorites_${user.uid}`);
      const savedLibrary = localStorage.getItem(`library_${user.uid}`);
      
      if (savedFavorites) setFavorites(JSON.parse(savedFavorites));
      if (savedLibrary) setLibrary(JSON.parse(savedLibrary));
    } else {
      setFavorites([]);
      setLibrary([]);
    }
  }, [user]);

  // Save to localStorage whenever data changes
  useEffect(() => {
    if (user) {
      localStorage.setItem(`favorites_${user.uid}`, JSON.stringify(favorites));
      localStorage.setItem(`library_${user.uid}`, JSON.stringify(library));
    }
  }, [favorites, library, user]);

  const addToFavorites = (song: Song) => {
    if (!user) {
      toast.error('Please sign in to add favorites');
      return;
    }
    if (!favorites.find(s => s.id === song.id)) {
      setFavorites([...favorites, song]);
      toast.success('Added to favorites');
    }
  };

  const removeFromFavorites = (songId: string) => {
    setFavorites(favorites.filter(song => song.id !== songId));
    toast.success('Removed from favorites');
  };

  const addToLibrary = (song: Song) => {
    if (!user) {
      toast.error('Please sign in to add to library');
      return;
    }
    if (!library.find(s => s.id === song.id)) {
      setLibrary([...library, song]);
      toast.success('Added to library');
    }
  };

  const removeFromLibrary = (songId: string) => {
    setLibrary(library.filter(song => song.id !== songId));
    toast.success('Removed from library');
  };

  const isFavorite = (songId: string) => favorites.some(song => song.id === songId);
  const isInLibrary = (songId: string) => library.some(song => song.id === songId);

  return (
    <LibraryContext.Provider
      value={{
        favorites,
        library,
        addToFavorites,
        removeFromFavorites,
        addToLibrary,
        removeFromLibrary,
        isFavorite,
        isInLibrary,
      }}
    >
      {children}
    </LibraryContext.Provider>
  );
}

export function useLibrary() {
  const context = useContext(LibraryContext);
  if (!context) {
    throw new Error('useLibrary must be used within a LibraryProvider');
  }
  return context;
}