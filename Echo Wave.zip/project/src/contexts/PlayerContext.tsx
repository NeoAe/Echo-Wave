import { createContext, useContext, useState, useRef, useEffect, ReactNode } from 'react';
import { Song } from '../types';

interface PlayerContextType {
  currentSong: Song | null;
  isPlaying: boolean;
  progress: number;
  volume: number;
  isShuffle: boolean;
  isRepeat: boolean;
  queue: Song[];
  playSong: (song: Song) => void;
  pauseSong: () => void;
  playNext: () => void;
  playPrevious: () => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  setProgress: (value: number) => void;
  setVolume: (value: number) => void;
  addToQueue: (song: Song) => void;
  removeFromQueue: (songId: string) => void;
}

const PlayerContext = createContext<PlayerContextType | null>(null);

export function PlayerProvider({ children }: { children: ReactNode }) {
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(0.7);
  const [isShuffle, setIsShuffle] = useState(false);
  const [isRepeat, setIsRepeat] = useState(false);
  const [queue, setQueue] = useState<Song[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const progressInterval = useRef<number>();
  const isDraggingRef = useRef(false);

  useEffect(() => {
    audioRef.current = new Audio();
    audioRef.current.volume = volume;

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      if (progressInterval.current) {
        window.clearInterval(progressInterval.current);
      }
    };
  }, []);

  const startProgressTracker = () => {
    if (progressInterval.current) {
      window.clearInterval(progressInterval.current);
    }

    progressInterval.current = window.setInterval(() => {
      if (audioRef.current && !isDraggingRef.current) {
        const currentProgress = (audioRef.current.currentTime / audioRef.current.duration) * 100;
        setProgress(currentProgress);

        if (currentProgress >= 100) {
          if (isRepeat) {
            audioRef.current.currentTime = 0;
            audioRef.current.play();
          } else {
            playNext();
          }
        }
      }
    }, 100);
  };

  const playSong = async (song: Song) => {
    try {
      if (!audioRef.current) return;

      if (currentSong?.id !== song.id) {
        audioRef.current.src = song.audioUrl;
        setCurrentSong(song);
      }

      audioRef.current.volume = volume;
      await audioRef.current.play();
      setIsPlaying(true);
      startProgressTracker();
    } catch (error) {
      console.error('Error playing song:', error);
    }
  };

  const pauseSong = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
      if (progressInterval.current) {
        window.clearInterval(progressInterval.current);
      }
    }
  };

  const playNext = () => {
    if (!currentSong || queue.length === 0) return;

    const currentIndex = queue.findIndex(song => song.id === currentSong.id);
    let nextSong: Song | undefined;

    if (isShuffle) {
      const remainingSongs = queue.filter(song => song.id !== currentSong.id);
      nextSong = remainingSongs[Math.floor(Math.random() * remainingSongs.length)];
    } else {
      nextSong = queue[currentIndex + 1];
    }

    if (nextSong) {
      playSong(nextSong);
    } else if (isRepeat) {
      playSong(queue[0]);
    } else {
      setIsPlaying(false);
      setProgress(0);
    }
  };

  const playPrevious = () => {
    if (!currentSong || queue.length === 0) return;

    const currentIndex = queue.findIndex(song => song.id === currentSong.id);
    const previousSong = queue[currentIndex - 1];

    if (previousSong) {
      playSong(previousSong);
    }
  };

  const toggleShuffle = () => setIsShuffle(!isShuffle);
  const toggleRepeat = () => setIsRepeat(!isRepeat);

  const updateProgress = (value: number) => {
    if (audioRef.current && currentSong) {
      isDraggingRef.current = false;
      const time = (value / 100) * audioRef.current.duration;
      audioRef.current.currentTime = time;
      setProgress(value);
      
      if (isPlaying) {
        audioRef.current.play();
      }
    }
  };

  const handleProgressDragStart = () => {
    isDraggingRef.current = true;
    if (audioRef.current && isPlaying) {
      audioRef.current.pause();
    }
  };

  const updateVolume = (value: number) => {
    if (audioRef.current) {
      audioRef.current.volume = value;
      setVolume(value);
    }
  };

  const addToQueue = (song: Song) => {
    if (!queue.find(s => s.id === song.id)) {
      setQueue([...queue, song]);
    }
  };

  const removeFromQueue = (songId: string) => {
    setQueue(queue.filter(song => song.id !== songId));
  };

  return (
    <PlayerContext.Provider
      value={{
        currentSong,
        isPlaying,
        progress,
        volume,
        isShuffle,
        isRepeat,
        queue,
        playSong,
        pauseSong,
        playNext,
        playPrevious,
        toggleShuffle,
        toggleRepeat,
        setProgress: updateProgress,
        setVolume: updateVolume,
        addToQueue,
        removeFromQueue,
      }}
    >
      {children}
    </PlayerContext.Provider>
  );
}

export function usePlayer() {
  const context = useContext(PlayerContext);
  if (!context) {
    throw new Error('usePlayer must be used within a PlayerProvider');
  }
  return context;
}