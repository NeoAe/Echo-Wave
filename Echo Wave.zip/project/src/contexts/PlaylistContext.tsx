import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Song } from '../types';
import { useAuth } from './AuthContext';
import toast from 'react-hot-toast';

export interface Playlist {
  id: string;
  name: string;
  songs: Song[];
  createdAt: number;
}

interface PlaylistContextType {
  playlists: Playlist[];
  createPlaylist: (name: string) => void;
  addToPlaylist: (playlistId: string, song: Song) => void;
  removeFromPlaylist: (playlistId: string, songId: string) => void;
  deletePlaylist: (playlistId: string) => void;
}

const PlaylistContext = createContext<PlaylistContextType | null>(null);

export function PlaylistProvider({ children }: { children: ReactNode }) {
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      const savedPlaylists = localStorage.getItem(`playlists_${user.uid}`);
      if (savedPlaylists) {
        setPlaylists(JSON.parse(savedPlaylists));
      }
    } else {
      setPlaylists([]);
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      localStorage.setItem(`playlists_${user.uid}`, JSON.stringify(playlists));
    }
  }, [playlists, user]);

  const createPlaylist = (name: string) => {
    if (!user) {
      toast.error('Please sign in to create a playlist');
      return;
    }
    const newPlaylist: Playlist = {
      id: Date.now().toString(),
      name,
      songs: [],
      createdAt: Date.now(),
    };
    setPlaylists([...playlists, newPlaylist]);
    toast.success('Playlist created');
  };

  const addToPlaylist = (playlistId: string, song: Song) => {
    setPlaylists(playlists.map(playlist => {
      if (playlist.id === playlistId && !playlist.songs.find(s => s.id === song.id)) {
        return { ...playlist, songs: [...playlist.songs, song] };
      }
      return playlist;
    }));
    toast.success('Song added to playlist');
  };

  const removeFromPlaylist = (playlistId: string, songId: string) => {
    setPlaylists(playlists.map(playlist => {
      if (playlist.id === playlistId) {
        return { ...playlist, songs: playlist.songs.filter(s => s.id !== songId) };
      }
      return playlist;
    }));
    toast.success('Song removed from playlist');
  };

  const deletePlaylist = (playlistId: string) => {
    setPlaylists(playlists.filter(p => p.id !== playlistId));
    toast.success('Playlist deleted');
  };

  return (
    <PlaylistContext.Provider
      value={{
        playlists,
        createPlaylist,
        addToPlaylist,
        removeFromPlaylist,
        deletePlaylist,
      }}
    >
      {children}
    </PlaylistContext.Provider>
  );
}

export function usePlaylist() {
  const context = useContext(PlaylistContext);
  if (!context) {
    throw new Error('usePlaylist must be used within a PlaylistProvider');
  }
  return context;
}