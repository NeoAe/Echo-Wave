import { Song } from '../types';

export const featuredSongs: Song[] = [
  {
    id: '1',
    title: 'Midnight Rain',
    artist: 'Luna Eclipse',
    cover: 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=800&auto=format&fit=crop&q=60',
    duration: '3:45',
    genre: 'Electronic',
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3'
  },
  {
    id: '2',
    title: 'Desert Wind',
    artist: 'Solar Beats',
    cover: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=800&auto=format&fit=crop&q=60',
    duration: '4:20',
    genre: 'Ambient',
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/10/25/audio_946f4d2ca3.mp3'
  },
  {
    id: '3',
    title: 'Urban Dreams',
    artist: 'City Lights',
    cover: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&auto=format&fit=crop&q=60',
    duration: '3:55',
    genre: 'Pop',
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/11/22/audio_febc7c1247.mp3'
  }
];