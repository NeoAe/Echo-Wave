import { Playlist } from '../types';

export const playlists: Playlist[] = [
  {
    id: '1',
    name: 'Chill Vibes',
    cover: 'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=800&auto=format&fit=crop&q=60',
    songCount: 45
  },
  {
    id: '2',
    name: 'Workout Mix',
    cover: 'https://images.unsplash.com/photo-1574700637332-8394d264817c?w=800&auto=format&fit=crop&q=60',
    songCount: 32
  },
  {
    id: '3',
    name: 'Focus Flow',
    cover: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=800&auto=format&fit=crop&q=60',
    songCount: 28
  }
];