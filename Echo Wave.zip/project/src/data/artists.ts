import { Artist } from '../types';

export const artists: Artist[] = [
  {
    id: '1',
    name: 'Luna Eclipse',
    image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=60',
    followers: 1200000,
    genres: ['Electronic', 'Pop']
  },
  {
    id: '2',
    name: 'Solar Beats',
    image: 'https://images.unsplash.com/photo-1511367461989-f85a21fda167?w=800&auto=format&fit=crop&q=60',
    followers: 890000,
    genres: ['Ambient', 'Electronic']
  },
  {
    id: '3',
    name: 'City Lights',
    image: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=800&auto=format&fit=crop&q=60',
    followers: 750000,
    genres: ['Pop', 'R&B']
  }
];