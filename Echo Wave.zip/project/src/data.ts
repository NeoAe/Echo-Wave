export const featuredSongs = [
  {
    id: '1',
    title: 'Midnight Rain',
    artist: 'Luna Eclipse',
    cover: 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=800&auto=format&fit=crop&q=60',
    duration: '3:45',
    genre: 'Electronic',
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3'
  },
  {
    id: '2',
    title: 'Desert Wind',
    artist: 'Solar Beats',
    cover: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=800&auto=format&fit=crop&q=60',
    duration: '4:20',
    genre: 'Ambient',
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/10/25/audio_946f4d2ca3.mp3'
  },
  {
    id: '3',
    title: 'Urban Dreams',
    artist: 'City Lights',
    cover: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&auto=format&fit=crop&q=60',
    duration: '3:55',
    genre: 'Pop',
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/11/22/audio_febc7c1247.mp3'
  }
];

export const playlists = [
  {
    id: '1',
    name: 'Chill Vibes',
    cover: 'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=800&auto=format&fit=crop&q=60',
    songCount: 45
  },
  {
    id: '2',
    name: 'Workout Mix',
    cover: 'https://images.unsplash.com/photo-1574700637332-8394d264817c?w=800&auto=format&fit=crop&q=60',
    songCount: 32
  },
  {
    id: '3',
    name: 'Focus Flow',
    cover: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=800&auto=format&fit=crop&q=60',
    songCount: 28
  }
];

export const artists = [
  {
    id: '1',
    name: 'Luna Eclipse',
    image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=60',
    followers: 1200000,
    genres: ['Electronic', 'Pop']
  },
  {
    id: '2',
    name: 'Solar Beats',
    image: 'https://images.unsplash.com/photo-1511367461989-f85a21fda167?w=800&auto=format&fit=crop&q=60',
    followers: 890000,
    genres: ['Ambient', 'Electronic']
  },
  {
    id: '3',
    name: 'City Lights',
    image: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=800&auto=format&fit=crop&q=60',
    followers: 750000,
    genres: ['Pop', 'R&B']
  }
];