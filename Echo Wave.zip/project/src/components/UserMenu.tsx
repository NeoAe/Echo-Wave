import { useState } from 'react';
import { LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { AuthModal } from './AuthModal';

export function UserMenu() {
  const { user, logout } = useAuth();
  const [showModal, setShowModal] = useState(false);

  if (!user) {
    return (
      <>
        <button
          onClick={() => setShowModal(true)}
          className="px-6 py-2 bg-purple-600 hover:bg-purple-700 rounded-full transition-colors font-medium text-white shadow-lg hover:shadow-purple-500/25"
        >
          Sign In
        </button>
        <AuthModal isOpen={showModal} onClose={() => setShowModal(false)} />
      </>
    );
  }

  return (
    <div className="flex items-center space-x-4">
      <div className="hidden md:block">
        <p className="text-sm font-medium">{user.email}</p>
      </div>
      <button
        onClick={() => logout()}
        className="p-2 hover:bg-gray-800 rounded-full transition-colors"
        title="Sign out"
      >
        <LogOut className="w-5 h-5" />
      </button>
    </div>
  );
}
