import { Heart, Plus, Minus, ListPlus } from 'lucide-react';
import { Song } from '../types';
import { usePlayer } from '../contexts/PlayerContext';
import { useLibrary } from '../contexts/LibraryContext';
import toast from 'react-hot-toast';

interface SongCardProps {
  song: Song;
  variant?: 'featured' | 'compact';
}

export function SongCard({ song, variant = 'featured' }: SongCardProps) {
  const { playSong, currentSong, isPlaying, pauseSong, addToQueue } = usePlayer();
  const { addToFavorites, removeFromFavorites, addToLibrary, removeFromLibrary, isFavorite, isInLibrary } = useLibrary();

  const handlePlay = () => {
    if (currentSong?.id === song.id && isPlaying) {
      pauseSong();
    } else {
      playSong(song);
    }
  };

  const handleFavoriteClick = () => {
    if (isFavorite(song.id)) {
      removeFromFavorites(song.id);
    } else {
      addToFavorites(song);
    }
  };

  const handleLibraryClick = () => {
    if (isInLibrary(song.id)) {
      removeFromLibrary(song.id);
    } else {
      addToLibrary(song);
    }
  };

  const handleAddToQueue = () => {
    addToQueue(song);
    toast.success('Added to queue');
  };

  if (variant === 'compact') {
    return (
      <div className="flex items-center justify-between p-3 hover:bg-gray-800 rounded-lg transition-colors">
        <div className="flex items-center space-x-3">
          <img src={song.cover} alt={song.title} className="w-12 h-12 rounded-md object-cover" />
          <div>
            <h3 className="font-medium">{song.title}</h3>
            <p className="text-sm text-gray-400">{song.artist}</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={handleFavoriteClick}
            className={`p-2 rounded-full hover:bg-gray-700 transition-colors ${
              isFavorite(song.id) ? 'text-purple-500' : 'text-gray-400'
            }`}
          >
            <Heart className="w-5 h-5" fill={isFavorite(song.id) ? 'currentColor' : 'none'} />
          </button>
          <button
            onClick={handleLibraryClick}
            className={`p-2 rounded-full hover:bg-gray-700 transition-colors ${
              isInLibrary(song.id) ? 'text-purple-500' : 'text-gray-400'
            }`}
          >
            {isInLibrary(song.id) ? (
              <Minus className="w-5 h-5" />
            ) : (
              <Plus className="w-5 h-5" />
            )}
          </button>
          <button
            onClick={handleAddToQueue}
            className="p-2 rounded-full hover:bg-gray-700 transition-colors text-gray-400 hover:text-white"
          >
            <ListPlus className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="group bg-gray-900 rounded-lg p-4 hover:bg-gray-800 transition-colors">
      <div className="relative mb-4">
        <img
          src={song.cover}
          alt={song.title}
          className="w-full aspect-square object-cover rounded-md"
        />
        <div className="absolute bottom-4 right-4 flex items-center space-x-2">
          <button
            onClick={handleFavoriteClick}
            className={`p-3 rounded-full bg-black bg-opacity-50 hover:bg-opacity-75 transition-all ${
              isFavorite(song.id) ? 'text-purple-500' : 'text-white'
            }`}
          >
            <Heart className="w-6 h-6" fill={isFavorite(song.id) ? 'currentColor' : 'none'} />
          </button>
          <button
            onClick={handlePlay}
            className="bg-purple-600 p-3 rounded-full hover:bg-purple-700 transition-colors"
          >
            {currentSong?.id === song.id && isPlaying ? (
              <Minus className="w-6 h-6" />
            ) : (
              <Plus className="w-6 h-6" />
            )}
          </button>
        </div>
      </div>
      <h3 className="font-semibold text-lg">{song.title}</h3>
      <p className="text-gray-400">{song.artist}</p>
      <div className="flex items-center justify-between mt-2 text-sm text-gray-400">
        <span>{song.genre}</span>
        <span>{song.duration}</span>
      </div>
    </div>
  );
}