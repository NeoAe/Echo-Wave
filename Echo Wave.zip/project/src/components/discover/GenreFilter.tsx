interface GenreFilterProps {
  genres: string[];
  selectedGenre: string;
  onSelectGenre: (genre: string) => void;
}

export function GenreFilter({ genres, selectedGenre, onSelectGenre }: GenreFilterProps) {
  return (
    <div className="flex flex-wrap gap-2 mb-8">
      {genres.map(genre => (
        <button
          key={genre}
          onClick={() => onSelectGenre(genre)}
          className={`px-4 py-2 rounded-full capitalize transition-colors ${
            selectedGenre === genre
              ? 'bg-purple-600 text-white'
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
          }`}
        >
          {genre}
        </button>
      ))}
    </div>
  );
}