import { Song } from '../../types';
import { SongCard } from '../SongCard';

interface SongGridProps {
  songs: Song[];
}

export function SongGrid({ songs }: SongGridProps) {
  if (songs.length === 0) {
    return (
      <div className="text-center text-gray-400 py-12">
        No songs found for this genre.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {songs.map(song => (
        <SongCard key={song.id} song={song} />
      ))}
    </div>
  );
}