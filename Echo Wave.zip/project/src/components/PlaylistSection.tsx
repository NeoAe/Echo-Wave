import { Play } from 'lucide-react';
import { Playlist } from '../types';

interface PlaylistSectionProps {
  playlists: Playlist[];
}

export function PlaylistSection({ playlists }: PlaylistSectionProps) {
  return (
    <section className="mb-12">
      <h2 className="text-2xl font-bold mb-6">Your Playlists</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {playlists.map((playlist) => (
          <div
            key={playlist.id}
            className="group bg-gray-900 rounded-lg p-4 hover:bg-gray-800 transition-colors"
          >
            <div className="relative mb-4">
              <img
                src={playlist.cover}
                alt={playlist.name}
                className="w-full aspect-square object-cover rounded-md"
              />
              <button className="absolute bottom-4 right-4 bg-purple-600 p-3 rounded-full opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-200">
                <Play className="w-6 h-6" />
              </button>
            </div>
            <h3 className="font-semibold">{playlist.name}</h3>
            <p className="text-sm text-gray-400">{playlist.songCount} songs</p>
          </div>
        ))}
      </div>
    </section>
  );
}