import { Play, Pause } from 'lucide-react';
import { Song } from '../types';
import { usePlayer } from '../contexts/PlayerContext';

interface FeaturedSectionProps {
  songs: Song[];
}

export function FeaturedSection({ songs }: FeaturedSectionProps) {
  const { playSong, currentSong, isPlaying, pauseSong } = usePlayer();

  const handlePlay = (song: Song) => {
    if (currentSong?.id === song.id && isPlaying) {
      pauseSong();
    } else {
      playSong(song);
    }
  };

  return (
    <section className="mb-12">
      <h2 className="text-2xl font-bold mb-6">Featured Tracks</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {songs.map((song) => (
          <div
            key={song.id}
            className="group bg-gray-900 rounded-lg p-4 hover:bg-gray-800 transition-colors"
          >
            <div className="relative mb-4">
              <img
                src={song.cover}
                alt={song.title}
                className="w-full aspect-square object-cover rounded-md"
              />
              <button
                onClick={() => handlePlay(song)}
                className="absolute bottom-4 right-4 bg-purple-600 p-3 rounded-full opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-200 hover:bg-purple-700"
              >
                {currentSong?.id === song.id && isPlaying ? (
                  <Pause className="w-6 h-6" />
                ) : (
                  <Play className="w-6 h-6" />
                )}
              </button>
            </div>
            <h3 className="font-semibold text-lg">{song.title}</h3>
            <p className="text-gray-400">{song.artist}</p>
            <div className="flex items-center justify-between mt-2 text-sm text-gray-400">
              <span>{song.genre}</span>
              <span>{song.duration}</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}