import { Home, Library, PlusCircle, Heart } from 'lucide-react';
import { Link } from './ui/Link';
import { UserMenu } from './UserMenu';
import { SearchBar } from './SearchBar';
import { useState } from 'react';
import { CreatePlaylistModal } from './CreatePlaylistModal';

interface NavbarProps {
  currentPage: 'home' | 'library' | 'favorites';
  onNavigate: (page: 'home' | 'library' | 'favorites') => void;
}

export function Navbar({ currentPage, onNavigate }: NavbarProps) {
  const [showCreatePlaylist, setShowCreatePlaylist] = useState(false);

  const NavButton = ({ page, icon: Icon, label }: { 
    page: 'home' | 'library' | 'favorites';
    icon: typeof Home;
    label: string;
  }) => (
    <button
      onClick={() => onNavigate(page)}
      className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
        currentPage === page 
          ? 'text-white bg-gray-800' 
          : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
      }`}
    >
      <Icon className="w-5 h-5" />
      <span>{label}</span>
    </button>
  );

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 bg-black bg-opacity-95 text-white z-50 px-6 py-4 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <button 
              onClick={() => onNavigate('home')} 
              className="text-2xl font-bold flex items-center"
            >
              <Library className="w-8 h-8 mr-2 text-purple-500" />
              Echo Waves
            </button>
            <div className="hidden md:flex items-center space-x-2">
              <NavButton page="home" icon={Home} label="Home" />
              <NavButton page="library" icon={Library} label="Library" />
              <NavButton page="favorites" icon={Heart} label="Favorites" />
            </div>
          </div>
          
          <div className="flex items-center space-x-6">
            <div className="hidden md:block">
              <SearchBar />
            </div>
            <button
              onClick={() => setShowCreatePlaylist(true)}
              className="hidden md:flex items-center space-x-1 bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-full transition-colors"
            >
              <PlusCircle className="w-5 h-5" />
              <span>Create Playlist</span>
            </button>
            <UserMenu />
          </div>
        </div>
      </nav>

      <CreatePlaylistModal
        isOpen={showCreatePlaylist}
        onClose={() => setShowCreatePlaylist(false)}
      />
    </>
  );
}