import { Play } from 'lucide-react';
import { Artist } from '../types';

interface ArtistSectionProps {
  artists: Artist[];
}

export function ArtistSection({ artists }: ArtistSectionProps) {
  return (
    <section className="mb-12">
      <h2 className="text-2xl font-bold mb-6">Popular Artists</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {artists.map((artist) => (
          <div
            key={artist.id}
            className="group bg-gray-900 rounded-lg p-4 hover:bg-gray-800 transition-colors"
          >
            <div className="relative mb-4">
              <img
                src={artist.image}
                alt={artist.name}
                className="w-full aspect-square object-cover rounded-full"
              />
              <button className="absolute bottom-4 right-4 bg-purple-600 p-3 rounded-full opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-200">
                <Play className="w-6 h-6" />
              </button>
            </div>
            <h3 className="font-semibold text-center">{artist.name}</h3>
            <p className="text-sm text-gray-400 text-center">
              {(artist.followers / 1000000).toFixed(1)}M followers
            </p>
            <div className="flex flex-wrap justify-center gap-2 mt-2">
              {artist.genres.map((genre) => (
                <span
                  key={genre}
                  className="text-xs bg-gray-800 text-gray-300 px-2 py-1 rounded-full"
                >
                  {genre}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}