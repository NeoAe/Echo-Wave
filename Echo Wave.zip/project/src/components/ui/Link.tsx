import { ReactNode } from 'react';

interface LinkProps {
  href: string;
  children: ReactNode;
  className?: string;
}

export function Link({ href, children, className = '' }: LinkProps) {
  return (
    <a 
      href={href} 
      className={`flex items-center space-x-2 text-gray-300 hover:text-white transition-colors ${className}`}
    >
      {children}
    </a>
  );
}