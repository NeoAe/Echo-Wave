{/* ... previous imports ... */}

export function MusicPlayer() {
  const {
    currentSong,
    isPlaying,
    progress,
    volume,
    isShuffle,
    isRepeat,
    queue,
    playSong,
    pauseSong,
    playNext,
    playPrevious,
    toggleShuffle,
    toggleRepeat,
    setProgress,
    setVolume,
  } = usePlayer();

  const [isDragging, setIsDragging] = useState(false);

  const handleProgressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number(e.target.value);
    setProgress(value);
  };

  const handleProgressMouseDown = () => {
    setIsDragging(true);
    if (isPlaying) {
      pauseSong();
    }
  };

  const handleProgressMouseUp = () => {
    setIsDragging(false);
    if (isPlaying) {
      playSong(currentSong!);
    }
  };

  if (!currentSong) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-black to-gray-900 text-white py-4 px-6">
      {/* ... other player UI elements ... */}
      <div className="w-full mt-2 flex items-center space-x-2">
        <span className="text-xs text-gray-400">
          {formatTime(progress / 100 * getDuration(currentSong.duration))}
        </span>
        <input
          type="range"
          min="0"
          max="100"
          value={progress}
          onChange={handleProgressChange}
          onMouseDown={handleProgressMouseDown}
          onMouseUp={handleProgressMouseUp}
          onTouchStart={handleProgressMouseDown}
          onTouchEnd={handleProgressMouseUp}
          className="flex-1 h-1 bg-gray-700 rounded-full appearance-none cursor-pointer
            [&::-webkit-slider-thumb]:appearance-none 
            [&::-webkit-slider-thumb]:w-3 
            [&::-webkit-slider-thumb]:h-3 
            [&::-webkit-slider-thumb]:rounded-full 
            [&::-webkit-slider-thumb]:bg-white
            [&::-webkit-slider-thumb]:hover:scale-110
            [&::-webkit-slider-thumb]:transition-transform"
        />
        <span className="text-xs text-gray-400">{currentSong.duration}</span>
      </div>
      {/* ... rest of the player UI ... */}
    </div>
  );
}