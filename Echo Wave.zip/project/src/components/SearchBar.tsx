import { useState, useEffect } from 'react';
import { Search as SearchIcon } from 'lucide-react';
import { Song } from '../types';
import { featuredSongs } from '../data';
import { SongCard } from './SongCard';

export function SearchBar() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Song[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    if (query.trim()) {
      const searchResults = featuredSongs.filter(song => 
        song.title.toLowerCase().includes(query.toLowerCase()) ||
        song.artist.toLowerCase().includes(query.toLowerCase()) ||
        song.genre.toLowerCase().includes(query.toLowerCase())
      );
      setResults(searchResults);
      setIsSearching(true);
    } else {
      setResults([]);
      setIsSearching(false);
    }
  }, [query]);

  return (
    <div className="relative">
      <div className="relative">
        <SearchIcon className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          placeholder="Search music..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="bg-gray-800 rounded-full py-2 pl-10 pr-4 w-64 focus:outline-none focus:ring-2 focus:ring-purple-500"
        />
      </div>

      {isSearching && (
        <div className="absolute top-full mt-2 w-96 bg-gray-900 rounded-lg shadow-lg overflow-hidden z-50">
          {results.length > 0 ? (
            <div className="max-h-96 overflow-y-auto">
              {results.map(song => (
                <SongCard key={song.id} song={song} variant="compact" />
              ))}
            </div>
          ) : (
            <div className="p-4 text-gray-400">
              No results found for "{query}"
            </div>
          )}
        </div>
      )}
    </div>
  );
}