import { X } from 'lucide-react';
import { usePlayer } from '../contexts/PlayerContext';

interface QueueListProps {
  onClose: () => void;
}

export function QueueList({ onClose }: QueueListProps) {
  const { queue, currentSong, playSong, removeFromQueue } = usePlayer();

  return (
    <div className="absolute bottom-full right-0 mb-2 w-80 bg-gray-900 rounded-lg shadow-xl p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold">Queue</h3>
        <button onClick={onClose} className="text-gray-400 hover:text-white">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="space-y-2 max-h-96 overflow-y-auto">
        {queue.length === 0 ? (
          <p className="text-gray-400 text-sm">Queue is empty</p>
        ) : (
          queue.map((song) => (
            <div
              key={song.id}
              className={`flex items-center justify-between p-2 rounded-lg ${
                currentSong?.id === song.id ? 'bg-purple-900/50' : 'hover:bg-gray-800'
              }`}
            >
              <button
                onClick={() => playSong(song)}
                className="flex items-center space-x-3 flex-1"
              >
                <img
                  src={song.cover}
                  alt={song.title}
                  className="w-10 h-10 rounded object-cover"
                />
                <div className="text-left">
                  <p className="font-medium">{song.title}</p>
                  <p className="text-sm text-gray-400">{song.artist}</p>
                </div>
              </button>
              <button
                onClick={() => removeFromQueue(song.id)}
                className="p-1 text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}