export interface Song {
  id: string;
  title: string;
  artist: string;
  cover: string;
  duration: string;
  genre: string;
  audioUrl: string;
}

export interface Playlist {
  id: string;
  name: string;
  cover: string;
  songCount: number;
}

export interface Artist {
  id: string;
  name: string;
  image: string;
  followers: number;
  genres: string[];
}