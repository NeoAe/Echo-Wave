import { Navbar } from './components/Navbar';
import { MusicPlayer } from './components/MusicPlayer';
import { Home } from './pages/Home';
import { Library } from './pages/Library';
import { Favorites } from './pages/Favorites';
import { useState } from 'react';
import { usePlayer } from './contexts/PlayerContext';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'library' | 'favorites'>('home');
  const { currentSong } = usePlayer();

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home />;
      case 'library':
        return <Library />;
      case 'favorites':
        return <Favorites />;
      default:
        return <Home />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white">
      <Navbar onNavigate={setCurrentPage} currentPage={currentPage} />
      <main className="max-w-7xl mx-auto px-6 pt-24 pb-32">
        {renderPage()}
      </main>
      {currentSong && <MusicPlayer />}
    </div>
  );
}